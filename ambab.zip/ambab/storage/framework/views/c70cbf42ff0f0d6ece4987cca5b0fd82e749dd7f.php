<?php $__env->startSection('content'); ?>
<div class="container">
	
</div>
<div class="container">
	<form action="/search" method="post" role="search">
		<table class="table table-striped">			
			<thead>
				<tr>
					<th>Pincode</th>
					<th>State</th>
					<th>District</th>
					<th>Division</th>
					<th>&nbsp;</th>
				</tr>
				<tr>
					<?php echo e(csrf_field()); ?>

					<td><input type="text" name="pincode" placeholder="Pincode" value="<?php echo e(old('pincode')); ?>"></td>
					<td><input type="text" name="statename" placeholder="State" value="<?php echo e(old('statename')); ?>"></td>
					<td><input type="text" name="districtname" placeholder="District" value="<?php echo e(old('districtname')); ?>"></td>
					<td><input type="text" name="divisionname" placeholder="Division" value="<?php echo e(old('divisionname')); ?>"></td>
					<td><button class="btn btn-group" type="submit">Search</button></td>
				</tr>
			</thead>
		<?php if(isset($data)): ?>
			<tbody>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($p->pincode); ?></td>
					<td><?php echo e($p->statename); ?></td>
					<td><?php echo e($p->districtname); ?></td>
					<td><?php echo e($p->divisionname); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			<?php echo $data->render(); ?>	
		<?php else: ?>
			<tr><td colspan="5"><?php echo e($message); ?></td></tr>
		<?php endif; ?>
			</tbody>	
		</table>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>